package com.example.roverbubt;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;



import java.net.SocketException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.UnknownHostException;


























import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;

import android.R.raw;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.ToneGenerator;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.SystemClock;
import android.os.Vibrator;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnLongClickListener;
import android.view.View.OnTouchListener;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.Toast;

public class SecondActivity extends Activity implements View.OnTouchListener{
	//Initializing all buttons 
	Button up,down,left,right,up_right,up_left,down_left,down_right,warn,mode,stop;
	Button corrent_btn = null;
	//check any error occurred or not
	boolean error=false;
	//check server sending response back or not
	boolean isDataBack=false;
	String rep="";
	//Initializing Socket type variables
	Socket socket=null,clientsocket=null;
	ServerSocket serverSocket;
	//reading data from server
	public InputStreamReader inputStreamReader;
	
	//Make Strings by getting server data    
	public BufferedReader bufferedReader;
	String _ip;
	String _port;
	int flag=0;
	boolean isButtonPressed=false;
	
	//Change the color of connect button if android connected to esp8266 server
	public void error_print()
	{
		if(rep.equals("ERROR"))
		{
			warn.setBackgroundResource(R.drawable.warn1);
			warn.getBackground().setAlpha(255);
			Toast.makeText(getBaseContext(), "NETWORK ERROR!", Toast.LENGTH_LONG).show();
		}
		else if(rep.equals("ok"))
		{
			warn.setBackgroundResource(R.drawable.warning_blue);
			warn.getBackground().setAlpha(255);
		}
	}
	String msg="Error";

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		//will hide the title of the activity
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		 //display the activity in full screen
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
		//prevent the screen from sleep mode 
		getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
		setContentView(R.layout.activity_second);
	
		//Receiving string from first activity
		_ip=getIntent().getStringExtra("IP");
		_port=getIntent().getStringExtra("PORT");
		//Initializing Buttons
		up=(Button) findViewById(R.id.btn_up);
		down=(Button) findViewById(R.id.btn_down);
		left=(Button) findViewById(R.id.btn_left);
		right=(Button) findViewById(R.id.btn_right);
		up_left=(Button) findViewById(R.id.btn_upleft);
		down_left=(Button) findViewById(R.id.btn_downleft);
		up_right=(Button) findViewById(R.id.btn_upright);
		down_right=(Button) findViewById(R.id.btn_downright);
		warn=(Button) findViewById(R.id.btn_warn);
		mode=(Button) findViewById(R.id.btn_mode);
		stop=(Button) findViewById(R.id.btn_stop);
		//setting up on touch functions for the buttons
		up.setOnTouchListener(this);
		down.setOnTouchListener(this);
		left.setOnTouchListener(this);
		right.setOnTouchListener(this);
		up_left.setOnTouchListener(this);
		up_right.setOnTouchListener(this);
		down_left.setOnTouchListener(this);
		down_right.setOnTouchListener(this);
		mode.setOnTouchListener(this);
		stop.setOnTouchListener(this);
		
		//Display which ip address and port will be connected
		Toast.makeText(getBaseContext(),"Corrent Ip:"+_ip+" & Port"+_port, Toast.LENGTH_LONG).show();;
		//request to connect with server by click on warn button
		warn.setOnLongClickListener(new OnLongClickListener() {
			
			@Override
			public boolean onLongClick(View view) {
			
				for(int i=0;i<=2;i++)
				{
				flag=0;
				new HttpRequestAsynTask_connect(
						view.getContext(),null,_ip,_port
					).execute();
				}
				Intent intent=new Intent(SecondActivity.this,First_Activity.class);
				startActivity(intent);
				return false;
			}
		});
		//setting up touch function for warn button
		warn.setOnTouchListener(new OnTouchListener() {
			
			@Override
			public boolean onTouch(View v, MotionEvent event) {
				flag=1;
		
				switch (event.getAction()) {
				case MotionEvent.ACTION_DOWN:
					warn.getBackground().setAlpha(100);
					
					break;
				case MotionEvent.ACTION_UP:
					if(isButtonPressed==false)
					{
						
					new HttpRequestAsynTask_connect(
							v.getContext(),null,_ip,_port
						).execute();
					error_print();
						
						isButtonPressed=true;
					
					}
					error_print();

					warn.getBackground().setAlpha(255);
					break;
				case MotionEvent.ACTION_MOVE:
	
					break;
	
				
				}
				return false;
			}
		});
		
		
		
	}
	private class HttpRequestAsynTask_connect extends AsyncTask<Void, Void, Void>
	{
		private String ip_address,requestReplay,port_name;
		private Context context;
		private AlertDialog alartdialog;
		private String parameter;
		private String parametervalue;
		
		public HttpRequestAsynTask_connect(Context context, String parametervalue,
				String ip_address, String port_name) {
			// TODO Auto-generated constructor stub
			this.context=context;
			this.ip_address=ip_address;
			this.parametervalue=parametervalue;
			this.port_name=port_name;
			
		}
		//Request to connect with server
		public String sendRequest_openport(String ip_address,String port_number) 
		{
			String serverResponse="ERROR";
			
			try{
			 socket = new Socket(ip_address,Integer.parseInt(port_number));
			 flag=1;
			
			 error=false;
			 serverResponse="ok";
			 Log.d("RCV","B4 RUN METHOD RUN");
			 new Thread(new Listen()).start();
			 return serverResponse;
			}catch(Exception e)
			{
				error=true;
	
				return serverResponse;
			}
			 
			 
			
			
		}
		//Run the thread for receive data when server response
		class Listen implements Runnable{
			
			@Override
			public void run() {
				String info="Not Initialized";
				try{
				
				 StringBuilder responseString = new StringBuilder();

				 
				}catch(Exception e){
					Log.d("RCV","Could not listen Port");
				}
				Log.d("RCV","INSIDE RUN");
				while(true)
			{
	
					try{
					StringBuilder responseString = new StringBuilder();
					BufferedReader bufferedReader = null;

			        bufferedReader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
			        String str;
			        if((str = bufferedReader.readLine()) != null){
			        while ((str = bufferedReader.readLine()) != null) {
			        	responseString.append(str);
			        	 int len=str.length();
					       char ch=str.charAt(len-1);
					       String s=""+ch;
					       if(s.equals("r"))
					       {
					    	   
					    	   
					    	   Log.d("Response2", "Data: "+s+"Data Back: "+isDataBack);
					       }
					       //if server send data v then android will give vibration and beep 
					       if(s.equals("v"))
					       {
					    	   Vibrator vb = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);

						    	// Vibrate for 1000 milliseconds
						    	vb.vibrate(1000);
					    	   ToneGenerator toneG = new ToneGenerator(AudioManager.STREAM_ALARM, 100);
					    	   toneG.startTone(ToneGenerator.TONE_CDMA_ALERT_CALL_GUARD, 200); 
					    	   toneG.release();
					    	
					       }
			            
			           
			        }
			        
			      
			       
			        
			        }else{
			        	Log.d("Response", "Server not responding");
			        }
					}catch(Exception e)
					{
						Log.d("RCV", "Error: "+e );
					}
				}

			
				
			}
			
		}
		public String sendRequest_close() throws UnknownHostException, IOException
		{
			
			String serverResponse="ERROR";
			
			
			try{
			 socket.close();
			 flag=0;
			 error=false;
			 Toast.makeText(getBaseContext(), "CONNECTED", Toast.LENGTH_LONG).show();
			 serverResponse="ok";
			}catch(Exception e)
			{
				
			error=true;
			}

			 
			 
			return serverResponse;
			
		}
		public String sendRequest_wrData(String parameterValue,String ip_address) throws UnknownHostException, IOException
		{
			Log.d("RCV2",msg);
			String serverResponse="ERROR";
			try{
			DataOutputStream DOS = new DataOutputStream(socket.getOutputStream());
			DOS.writeUTF(parameterValue);
			

			flag=2;
			error=false;
			serverResponse="ok";
			
			}catch(Exception e)
			{
				
			error=true;
			serverResponse="ERROR";
			msg="Error: "+e;
			}
			 
			 
			return serverResponse;
			
		}
		

		@Override
		protected Void doInBackground(Void... voids) {
			// TODO Auto-generated method stub
			try {
				if(flag==0)
				requestReplay=sendRequest_close();
				else if(flag==1){
					requestReplay=sendRequest_openport(ip_address,port_name);
					rep=requestReplay;
					
				}
				else if(flag==2)
					requestReplay=sendRequest_wrData(parametervalue,ip_address);
				
			} catch (IOException e) {
				// TODO Auto-generated catch block
				
				e.printStackTrace();
			}
			return null;
		}
		protected void onPostExecution(Void avoid)
		{
			//alartdialog.setMessage(requestReplay);
		}
		protected void onPreExecution() {
			//alartdialog.setMessage("Sending data to server... Pleasewait");
			
		}
		
	}
	boolean presstwich=false;
	
@Override
public void onBackPressed() {
	if(presstwich==true)
	{
		Intent intent=new Intent(Intent.ACTION_MAIN);
		intent.addCategory(Intent.CATEGORY_HOME);
		intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
		startActivity(intent);
		finish();
		System.exit(0);
	}
	presstwich=true;
	Toast.makeText(getBaseContext(), "press BACK button again to exit", Toast.LENGTH_LONG).show();;
	new Handler().postDelayed(new Runnable() {
		
		@Override
		public void run() {
			presstwich=false;
			
		}
	}, 2000);
}
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.second, menu);
		
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}

	@Override
	public boolean onTouch(View v, MotionEvent event) {
		// TODO Auto-generated method stub
		String parameterValue="";
		//sending different data by clicking different buttons
		if(v.getId()==up.getId())
		{
			parameterValue="U";
			corrent_btn=up;
			
		}
		if(v.getId()==down.getId())
		{
			parameterValue="D";
			corrent_btn=down;
		}if(v.getId()==left.getId())
		{
			parameterValue="L";
			corrent_btn=left;
		}if(v.getId()==right.getId())
		{
			parameterValue="R";
			corrent_btn=right;
		}if(v.getId()==up_left.getId())
		{
			parameterValue="1";
			corrent_btn=up_left;
		}if(v.getId()==up_right.getId())
		{
			parameterValue="2";
			corrent_btn=up_right;
		}if(v.getId()==down_left.getId())
		{
			parameterValue="3";
			corrent_btn=down_left;
		}if(v.getId()==down_right.getId())
		{
			parameterValue="4";
			corrent_btn=down_right;
		}

		if(v.getId()==mode.getId())
		{
			parameterValue="M";
			corrent_btn=mode;
		}if(v.getId()==stop.getId())
		{
			parameterValue="S";
			corrent_btn=stop;
		}
		switch (event.getAction()) {
		//function for tap on a button
		case MotionEvent.ACTION_DOWN:
		
			corrent_btn.getBackground().setAlpha(100);
			flag=2;
			//sending data repeatedly so that data loss prediction will be decreased 
			for(int i=0;i<2;i++){
			new HttpRequestAsynTask_connect(
					v.getContext(),parameterValue,_ip,_port
				).execute();
			error_print();
		}
	
			break;
		//function for release button
		case MotionEvent.ACTION_UP:
		
			
			//sending data repeatedly so that data loss prediction will be decreased  
		    for(int i=0;i<2;i++){
		    new HttpRequestAsynTask_connect(
		    		//sending s data when button released
					v.getContext(),"S",_ip,_port
				).execute();
			error_print();
		}
		    
			//reset the graphics of the background
			corrent_btn.getBackground().setAlpha(255);
			
			break;

		case MotionEvent.ACTION_MOVE:
			break;
		}
		return false;
	}
	
}
